const revealItems=document.querySelectorAll('.reveal');
const observer=new IntersectionObserver((entries)=>entries.forEach(entry=>{if(entry.isIntersecting)entry.target.classList.add('in')}),{threshold:.12});
revealItems.forEach(el=>observer.observe(el));
const hero=document.querySelector('.hero');
let ticking=false;
window.addEventListener('scroll',()=>{if(ticking)return;ticking=true;requestAnimationFrame(()=>{const y=window.scrollY;if(hero){hero.style.setProperty('--scroll',y);const green=hero.querySelector('.hero-green');const hood=hero.querySelector('.hero-hood');if(green)green.style.transform=`translateY(${Math.min(y*.06,35)}px) rotate(-5deg)`;if(hood)hood.style.transform=`translateY(${Math.min(y*.04,25)}px) rotate(8deg)`;}ticking=false})},{passive:true});
document.querySelectorAll('a[href^="#"]').forEach(link=>link.addEventListener('click',e=>{const target=document.querySelector(link.getAttribute('href'));if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth',block:'start'})}}));
