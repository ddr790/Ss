# NG GAMES — Original Rebuild

Versão refeita do zero usando o ZIP original como base de assets e tipografia.

## Direção visual
- Branco / creme como base
- Laranja como cor de energia
- Amarelo-claro para destaque
- Tipografia Futura do projeto
- Personagens e logos originais do pacote

## Responsividade
O layout foi refeito para desktop, tablet e celular sem overflow horizontal. As imagens foram preparadas com fundo preto removido apenas nas áreas pretas conectadas às bordas, preservando os traços pretos internos dos personagens.

## Rodar
```bash
python3 -m http.server 8080
```
Abra a porta 8080 no Codespaces.
